import React from "react";
import Header from "./Header";
import CreateNote from "./CreatNote";
import Footer from "./Footer";
import Note from "./Note";
import "./App.css"

const Appkeep = ()=>{
    return(<>
     <div>
      <Header />
      <CreateNote/>
      {/* <Note/> */}
      <Footer />
     </div>
    </>);
}; 
export default Appkeep;