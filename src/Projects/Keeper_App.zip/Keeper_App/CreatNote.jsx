import React, { useState } from "react";
import Note from "./Note";
const CreateNote=()=>{
    const[isExpand,setIsExpand] = useState({
        expand:"",
        number:1
    });
    const handleInputClick = (e) => {
        setIsExpand({
            expand:true,
            number:3
        }); 
        setTitle((p)=>{
            let name = e.target.name;
            if(name === "title"){
                return({
                    ...p,
                    [name] : e.target.value
                })
            }else{
                return({
                    ...p,
                    [name] : e.target.value
                })
            }
        });
    }; 
    const[note,setTitle] = useState({
        title:"",
        text:""
    });
    const submit = () =>{
        console.log("Vaibhav");
        <Note title={note.title} text={note.text}/> 
    }
    return(<>
        <div>
            <form>
                {isExpand.expand && <input placeholder="Title" name="title" onChange={handleInputClick} value={note.title}/>}
                <textarea placeholder="Take a note..." rows={isExpand.number} name="text" onChange={handleInputClick} onClick={handleInputClick} value={note.text}/>
                <button type="submit" onClick={submit} >➕</button>
            </form>
        </div>  
    </>);
} 

export default CreateNote;

