import React from "react";
import DeleteIcon from '@mui/icons-material/Delete';

const Note=(props)=>{
    console.log(props);
    return(<>
         <div className="note">
             <h1>{props.title}</h1>
             <p>{props.text}</p>
             <button>
              <DeleteIcon />
             </button>
        </div>
    </>);
}

export default Note;