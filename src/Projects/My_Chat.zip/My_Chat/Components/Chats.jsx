import React from "react";
import profile from "../imges/profile-myChat.jpg"
const Chats=()=>{
    return(<>
       <div className="user-chat">
            <img src={profile} alt="" />
            <div className="user-chat-info">
                <span>Jhon</span>
                <p>Hello</p>
            </div>
        </div>
        <div className="user-chat">
            <img src={profile} alt="" />
            <div className="user-chat-info">
                <span>Jhon</span>
                <p>Hello</p>
            </div>
        </div>
        <div className="user-chat">
            <img src={profile} alt="" />
            <div className="user-chat-info">
                <span>Jhon</span>
                <p>Hello</p>
            </div>
        </div>
        <div className="user-chat">
            <img src={profile} alt="" />
            <div className="user-chat-info">
                <span>Jhon</span>
                <p>Hello</p>
            </div>
        </div>
    </>)
} 

export default Chats;