import React from "react";
import attach from "../imges/attach.png";
import img from "../imges/img.png";
const Input=()=>{
    return(<>
        <div className="inputField">
            <input type="text" placeholder="Type something...."/>
            <div className="input-send">
                <img src={attach} alt="" />
                <input type="file" style={{display:"none"}} id="file" />
                <label htmlFor="file">
                    <img src={img} alt="" />
                </label>
                <button>Send</button>
            </div>
        </div>
    </>)
} 

export default Input;