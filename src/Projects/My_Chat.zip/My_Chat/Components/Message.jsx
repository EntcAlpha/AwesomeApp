import React from "react";
import profile from "../imges/profile-myChat.jpg";
const Message=()=>{
    return(<>
         <div className="message">
            <div className="message-info">
                <img src={profile} alt="" /> 
                <span>just now</span>
            </div>
            <div className="message-content">
                <p>Hello</p>
                <img src={profile} alt="" />
            </div>
        </div> 
        <div className="message-owner">
            <div className="message-info">
                <img src={profile} alt="" /> 
                <span>just now</span>
            </div>
            <div className="message-content">
                <p>Hello</p>  
                <img src={profile} alt="" />
            </div>
        </div> 
    </>)
} 

export default Message;