import React from "react";
import profile from "../imges/profile-myChat.jpg"
const Search=()=>{
    return(<>
        <div className="search">
            <div className="search-user">
              <input type="text" placeholder="Find a user"/>
            </div>
            <div className="user-chat">
                <img src={profile} alt="" />
                <div className="user-chat-info">
                    <span>Jhon</span>
                </div>
            </div>
        </div>
    </>)
} 

export default Search;