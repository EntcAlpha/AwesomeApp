import React from "react";

const Header=()=>{
    return(<>
        <header>
         <img src={require("./logo.jpg")} alt="" width="50px" height="50px"/>
         <h1>Vaibhav Keep</h1>
        </header>
    </>);
} 

export default Header;